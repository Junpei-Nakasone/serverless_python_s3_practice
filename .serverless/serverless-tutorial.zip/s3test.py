
def handler(event, context):
  print('object created on S320220120.')
